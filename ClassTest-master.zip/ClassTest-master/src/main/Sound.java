package main;

public class Sound {
	
	public double calculation(double time, double speed) {
		
		double distance = time*speed;
		return distance;
		
	}

}
